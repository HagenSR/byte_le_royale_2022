

class InventoryFullError(Exception):
    """Exception raised when player inventory is full"""
    pass
